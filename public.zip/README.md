# React + Vite | Google AI Gemini Integration

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Resources:

https://vitejs.dev/

https://deepmind.google/

https://ai.google.dev/tutorials/web_quickstart?hl=en

https://www.npmjs.com/package/@google/generative-ai

Developed by: Nijat Aliyev

## Follow us:

YouTube: youtube.com/@developer_nijat

Telegram: t.me/js_az

TikTok: tiktok.com/@developer.nijat

Facebook: fb.com/groups/1298499510834490

Website: aliyev.dev


